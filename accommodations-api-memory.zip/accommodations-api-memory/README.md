# Manten Accommodations API Memory

# Prerequisites
You need to have Docker installed on your machine.

# Set Up
In your terminal execute:  
`cd <path-to-this-directory>`  
`docker build -t manten-accommodations-api-memory .`

After that you can start the container with:  
`docker run -p 8080:8080 --name manten-accommodations-api-memory-container manten-accommodations-api-memory`  
All endpoints will be available under http://localhost:8080/ (for example http://localhost:8080/flat-examinations)

You can stop the container with:  
`docker stop manten-accommodations-api-memory-container`

## Documentation
All endpoints provided by this API can be found under `http://localhost:8080/swagger-ui.html`
