CREATE TABLE "DBA"."L_Wohnungen" (
        "Woid" INTEGER NOT NULL DEFAULT AUTOINCREMENT,
        "WoAdrId" INTEGER NOT NULL,
        "WoMiete" DOUBLE NULL,
        "WoMaxPersonen" INTEGER NULL,
        "CompID" INTEGER NOT NULL,
        "WoVertrag" CHAR(30) NULL,
        "WoMakler" CHAR(100) NULL,
        "WoWohnung" CHAR(100) NULL,
        "WoNebenkosten" DOUBLE NULL,
        "WoKaution" DOUBLE NULL,
        "WoFlaeche" INTEGER NULL,
        "WoAnzahlBad" INTEGER NULL,
        "WoAnzahlKueche" INTEGER NULL,
        "WoAnzahlFlur" INTEGER NULL,
        "WoAnzahlBalkon" INTEGER NULL,
        "WoAnzahlZimmer" INTEGER NULL,
        "WoVermieterAdressID" INTEGER NULL,
        "MandantId" INTEGER NOT NULL,
        "WoStrom" DOUBLE NULL,
        "WoZaehlerNr" CHAR(30) NULL,
        "WoStromvertragsnummer" CHAR(30) NULL,
        "WoGasvertragsnummer" CHAR(30) NULL,
        "WoGas" DOUBLE NULL,
        "WoGasZaehlerNr" CHAR(30) NULL,
        "WoStromAnbieter" CHAR(30) NULL,
        "WoGasAnbieter" CHAR(30) NULL,
        "WoKostenstelleID" INTEGER NULL,
        "WoGasVertragNeuAb" DATE NULL,
        "WoStromVertragNeuAb" DATE NULL,
        "WoAmpelStatus" INTEGER NOT NULL DEFAULT 0,
        "WoAmpelStatusZwei" INTEGER NULL DEFAULT 0,
        "WoStatusDatum" DATE NULL,
        "WoStatusInfo" CHAR(40) NULL,
        "WoNaechsteKontrolle" DATE NULL,
        "WoVerantwortlicherID" INTEGER NULL,
        PRIMARY KEY ( "Woid" ASC )
) IN "system";
COMMENT ON TABLE "DBA"."L_Wohnungen" IS '##GLP';
CREATE TABLE "DBA"."L_WohnungArtikel" (
        "WAID" INTEGER NOT NULL DEFAULT AUTOINCREMENT,
        "CompID" INTEGER NOT NULL,
        "WAWohnungID" INTEGER NOT NULL,
        "WAZimmerID" INTEGER NULL,
        "WAArtikelID" INTEGER NOT NULL,
        "WAAnzahl" INTEGER NOT NULL DEFAULT 1,
        "WABemerkung" CHAR(512) NULL,
        PRIMARY KEY ( "WAID" ASC )
) IN "system";
COMMENT ON TABLE "DBA"."L_WohnungArtikel" IS '##GLP';
CREATE TABLE "DBA"."L_Zimmer" (
        "ZIID" INTEGER NOT NULL DEFAULT AUTOINCREMENT,
        "CompID" INTEGER NOT NULL,
        "MandantID" INTEGER NOT NULL,
        "ZIWohnungID" INTEGER NOT NULL,
        "ZIZimmerNummer" CHAR(25) NOT NULL,
        "ZIEtage" INTEGER NULL,
        "ZISeite" INTEGER NULL,
        "ZIBemerkung" LONG VARCHAR NULL,
        PRIMARY KEY ( "ZIID" ASC )
) IN "system";
COMMENT ON TABLE "DBA"."L_Zimmer" IS '##GLP';

CREATE TABLE "DBA"."L_KatalogWohnung" (
        "KWID" INTEGER NOT NULL DEFAULT AUTOINCREMENT,
        "CompID" INTEGER NOT NULL,
        "KWBezeichnung" CHAR(60) NOT NULL,
        "KWTyp" INTEGER NOT NULL DEFAULT 1,
        "KWIntervall" INTEGER NOT NULL DEFAULT 0,
        "KWIntervallBezug" CHAR(20) NOT NULL DEFAULT 'day',
        "KWStausRelevant" BIT NOT NULL DEFAULT 0,
        "KWBemerkung" CHAR(512) NULL,
        PRIMARY KEY ( "KWID" ASC )
) IN "system";
COMMENT ON TABLE "DBA"."L_KatalogWohnung" IS '##GLP';
CREATE TABLE "DBA"."L_KatalogWohnungAufgabe" (
        "KWAID" INTEGER NOT NULL DEFAULT AUTOINCREMENT,
        "CompID" INTEGER NOT NULL,
        "KWAMassnahmeID" INTEGER NOT NULL,
        "KWABezeichnung" CHAR(100) NOT NULL,
        "KWABeschreibung" CHAR(512) NOT NULL,
        "KWATyp" INTEGER NOT NULL DEFAULT 1,
        "KWABezug" INTEGER NOT NULL DEFAULT 1,
        "KWABemerkung" CHAR(512) NULL,
        PRIMARY KEY ( "KWAID" ASC )
) IN "system";
COMMENT ON TABLE "DBA"."L_KatalogWohnungAufgabe" IS '##GLP';
COMMENT ON COLUMN "DBA"."L_KatalogWohnungAufgabe"."KWATyp" IS '1: Einzelaufgabe, 2: ProWohnungsartikel';
COMMENT ON COLUMN "DBA"."L_KatalogWohnungAufgabe"."KWABezug" IS '1: Pro Wohnung, 2: Pro Zimmer';


/// Maaßnahmen:
CREATE TABLE "DBA"."L_WohnungsAufgabe" (
        "WAID" INTEGER NOT NULL DEFAULT AUTOINCREMENT,
        "CompID" INTEGER NOT NULL,
        "WAMassnahmeID" INTEGER NOT NULL,
        "WaBeschreibung" CHAR(255) NOT NULL,
        "WaKatalogAufgabeID" INTEGER NULL,
        "WaInventarID" INTEGER NULL,
        "WaErgebnis" BIT NOT NULL DEFAULT 0,
        "WaBemerkung" CHAR(512) NULL,
        PRIMARY KEY ( "WAID" ASC )
) IN "system";
COMMENT ON TABLE "DBA"."L_WohnungsAufgabe" IS '##GLP';
CREATE TABLE "DBA"."L_WohnungsMassnahme" (
        "WMID" INTEGER NOT NULL DEFAULT AUTOINCREMENT,
        "CompID" INTEGER NOT NULL,
        "WMKatalogID" INTEGER NOT NULL,
        "WMTerminGeplant" DATE NOT NULL,
        "WMTerminDurchfuehrung" DATE NULL,
        "WMVerantwortlichMitarbeiterID" INTEGER NOT NULL,
        "WMVerantwortlichExtern" CHAR(255) NULL,
        "WMDringlichkeit" INTEGER NOT NULL DEFAULT 1,
        "WMVorherigeMassnahmeID" INTEGER NULL,
        "WMWohnungID" INTEGER NULL,
        "WMZimmerID" INTEGER NULL,
        "WMStatusID" INTEGER NOT NULL,
        "WMWohnungsStatus" INTEGER NULL,
        "WMBemerkung" CHAR(512) NULL,
        PRIMARY KEY ( "WMID" ASC )
) IN "system";
COMMENT ON TABLE "DBA"."L_WohnungsMassnahme" IS '##GLP
';
COMMENT ON COLUMN "DBA"."L_WohnungsMassnahme"."WMDringlichkeit" IS '1: niedrigste Dringlichkeit';

ALTER TABLE "DBA"."L_WohnungsMassnahme" ADD CONSTRAINT "L_KatalogWohnung" NOT NULL FOREIGN KEY ( "WMKatalogID" ASC ) REFERENCES "DBA"."L_KatalogWohnung" ( "KWID" );
ALTER TABLE "DBA"."L_WohnungsAufgabe" ADD CONSTRAINT "L_KatalogWohnungAufgabe" FOREIGN KEY ( "WaKatalogAufgabeID" ASC ) REFERENCES "DBA"."L_KatalogWohnungAufgabe" ( "KWAID" );
ALTER TABLE "DBA"."L_WohnungsAufgabe" ADD CONSTRAINT "L_WohnungArtikel" FOREIGN KEY ( "WaInventarID" ASC ) REFERENCES "DBA"."L_WohnungArtikel" ( "WAID" );
ALTER TABLE "DBA"."L_WohnungsAufgabe" ADD CONSTRAINT "L_WohnungsMassnahme" NOT NULL FOREIGN KEY ( "WAMassnahmeID" ASC ) REFERENCES "DBA"."L_WohnungsMassnahme" ( "WMID" );
ALTER TABLE "DBA"."L_KatalogWohnungAufgabe" ADD CONSTRAINT "L_KatalogWohnung" NOT NULL FOREIGN KEY ( "KWAMassnahmeID" ASC ) REFERENCES "DBA"."L_KatalogWohnung" ( "KWID" );