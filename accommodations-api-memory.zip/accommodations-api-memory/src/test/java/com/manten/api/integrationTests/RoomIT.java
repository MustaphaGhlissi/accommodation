package com.manten.api.integrationTests;

import com.manten.api.room.Room;
import com.manten.api.room.RoomRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@Transactional
public class RoomIT {

    @Autowired
    private RoomRepository roomRepository;

    @Test
    public void test_create_room(){
        Room roomInserted = roomRepository.save(new Room(null, 1l, 1l, 1l, "1", 1l, 1l, "test remark"));
        assertNotNull(roomRepository.findById(roomInserted.getId()).get());
    }

}
