package com.manten.api.integrationTests;

import com.manten.api.flat.Flat;
import com.manten.api.flatExamination.FlatExamination;
import com.manten.api.flatExamination.FlatExaminationRepository;
import com.manten.api.flatExaminationTask.FlatExaminationTask;
import com.manten.api.flatExaminationTask.FlatExaminationTaskRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@Transactional
public class FlatExaminationTaskIT {

    @Autowired
    private FlatExaminationTaskRepository flatExaminationTaskRepository;

    @Autowired
    private FlatExaminationRepository flatExaminationRepository;

    @BeforeEach
    public void beforeEach(){
        flatExaminationRepository.deleteAll();
        flatExaminationTaskRepository.deleteAll();
    }

    /*@Test
    public void test_flat_examination_task_create(){
        //FlatExamination flatExamination = flatExaminationRepository.save(new FlatExamination(null, 1l, 1l, 1l, 1l, "Max Mustermann", 1l, 1l, "2020-05-19", "2020-05-23", 1, 1, 1, "roses are red"));
        //FlatExamination flatExaminationFetched = flatExaminationRepository.findById(flatExamination.getId()).orElse(null);
        //assertNotNull(flatExaminationFetched);

        //FlatExaminationTask flatExaminationTask = flatExaminationTaskRepository.save(new FlatExaminationTask(null, 1l, flatExaminationFetched.getId(), 1l, "test", 1l, true, "test"));
        //assertNotNull(flatExaminationTaskRepository.findById(flatExaminationTask.getId()).orElse(null));
    }*/

}
