package com.manten.api.integrationTests;

import com.manten.api.flatExamination.FlatExamination;
import com.manten.api.flatExamination.FlatExaminationRepository;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@Transactional
public class FlatExaminationIT {
    @Autowired
    private FlatExaminationRepository flatExaminationRepository;

    @Test
    public void test_flat_examination_create(){
        //FlatExamination flatExamination = flatExaminationRepository.save(new FlatExamination(null, 1l, 1l, 1l, 1l, "Max Mustermann", 1l, 1l, "2020-05-19", "2020-05-23", 1, 1, 1, "roses are red"));
        //assertNotNull(flatExaminationRepository.findById(flatExamination.getId()));
    }
}
