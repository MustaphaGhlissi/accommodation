package com.manten.api.integrationTests;

import com.manten.api.flat.Flat;
import com.manten.api.flat.FlatRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@Transactional
public class FlatIT {

    @Autowired
    private FlatRepository flatRepository;

    @Test
    public void test_flat_create(){
        Flat flat = flatRepository.save(new Flat(null, 1l, 1l, 1l, 1, "sample name"));
        assertNotNull(flatRepository.findById(flat.getId()).orElse(null));
    }

}
