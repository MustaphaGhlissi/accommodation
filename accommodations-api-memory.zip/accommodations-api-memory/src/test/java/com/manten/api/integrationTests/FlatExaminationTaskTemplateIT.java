package com.manten.api.integrationTests;

import com.manten.api.flatExaminationTaskTemplate.FlatExaminationTaskTemplate;
import com.manten.api.flatExaminationTaskTemplate.FlatExaminationTaskTemplateRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@Transactional
public class FlatExaminationTaskTemplateIT {

    @Autowired
    private FlatExaminationTaskTemplateRepository flatExaminationTaskTemplateRepository;

    /*@Test
    public void test_flat_create(){
        FlatExaminationTaskTemplate flatExaminationTaskTemplate = flatExaminationTaskTemplateRepository.save(new FlatExaminationTaskTemplate(null, 1l, "test", "test", 1, 1, "test"));
        assertNotNull(flatExaminationTaskTemplateRepository.findById(flatExaminationTaskTemplate.getId()));
    }*/

}
