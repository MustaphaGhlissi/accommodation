package com.manten.api.integrationTests;

import com.manten.api.flat.Flat;
import com.manten.api.flatExaminationTemplate.FlatExaminationTemplate;
import com.manten.api.flatExaminationTemplate.FlatExaminationTemplateRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@Transactional
public class FlatExaminationTemplateIT {

    @Autowired
    private FlatExaminationTemplateRepository flatExaminationTemplateRepository;

    @Test
    public void test_flat_create(){
        FlatExaminationTemplate flatExaminationTemplate = flatExaminationTemplateRepository.save(new FlatExaminationTemplate(null, "test", 1, 1, "test", true, "test"));
        assertNotNull(flatExaminationTemplateRepository.findById(flatExaminationTemplate.getId()));
    }

}
