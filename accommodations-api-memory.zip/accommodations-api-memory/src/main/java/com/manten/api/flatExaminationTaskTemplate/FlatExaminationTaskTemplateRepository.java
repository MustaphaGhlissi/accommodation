package com.manten.api.flatExaminationTaskTemplate;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FlatExaminationTaskTemplateRepository extends JpaRepository<FlatExaminationTaskTemplate, Long> {
}
