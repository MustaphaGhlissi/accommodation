package com.manten.api.flatExaminationTaskTemplate;

import javax.persistence.*;

@Entity
@Table(name = "L_KatalogWohnungAufgabe")
public class FlatExaminationTaskTemplate {

    @Id
    @Column(name = "KWAID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "KWAMassnahmeID")
    private Long flatExaminationTemplateId;

    @Column(name = "KWABezeichnung")
    private String name;

    @Column(name = "KWABeschreibung")
    private String description;

    @Column(name = "KWATyp")
    private Integer type;

    @Column(name = "KWABezug")
    private Integer reference;

    @Column(name = "KWABemerkung")
    private String remark;

    public FlatExaminationTaskTemplate() {
    }

    public FlatExaminationTaskTemplate(Long id, Long flatExaminationTemplateId, String name, String description, Integer type, Integer reference, String remark) {
        this.id = id;
        this.flatExaminationTemplateId = flatExaminationTemplateId;
        this.name = name;
        this.description = description;
        this.type = type;
        this.reference = reference;
        this.remark = remark;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFlatExaminationTemplateId() {
        return flatExaminationTemplateId;
    }

    public void setFlatExaminationTemplateId(Long flatExaminationTemplateId) {
        this.flatExaminationTemplateId = flatExaminationTemplateId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getReference() {
        return reference;
    }

    public void setReference(Integer reference) {
        this.reference = reference;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
