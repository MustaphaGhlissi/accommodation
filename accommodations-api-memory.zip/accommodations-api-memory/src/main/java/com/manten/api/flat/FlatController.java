package com.manten.api.flat;

import com.manten.api.utils.Utils;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Validated
public class FlatController {

    private FlatRepository flatRepository;

    public FlatController(FlatRepository flatRepository){
        this.flatRepository = flatRepository;
    }

    @GetMapping("/flats")
    List<Flat> all(){
        return flatRepository.findAll();
    }

    @PostMapping("/flats")
    Flat create(@RequestBody @Valid Flat flat){
        return flatRepository.save(flat);
    }

    @PatchMapping("/flats/{flatId}")
    Flat update(@RequestBody Flat flat, @PathVariable Long flatId){
        return flatRepository.save((Flat) Utils.mergeObjects(flatRepository.findById(flatId).get(), flat));
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        String message = "";
        List<ObjectError> objectErrors = ex.getBindingResult().getAllErrors();
        for (int i = 0; i < objectErrors.size(); i++){
            ObjectError error = objectErrors.get(i);
            errors.put(((FieldError) error).getField(), error.getDefaultMessage());
        }
        return errors;
    }

}
