package com.manten.api.flatItem;

import com.manten.api.flatExamination.FlatExamination;
import com.manten.api.utils.Utils;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class FlatItemController {

    private FlatItemRepository flatItemRepository;

    public FlatItemController(FlatItemRepository flatItemRepository){
        this.flatItemRepository = flatItemRepository;
    }

    @GetMapping("/flat-items")
    List<FlatItem> all(){
        return flatItemRepository.findAll();
    }

    @PostMapping("/flat-items")
    FlatItem create(@RequestBody @Valid FlatItem flatItem){
        return flatItemRepository.save(flatItem);
    }

    @PatchMapping("/flat-items/{flatItemId}")
    FlatItem update(@RequestBody FlatItem flatItem, @PathVariable Long flatItemId){
        return flatItemRepository.save((FlatItem) Utils.mergeObjects(flatItemRepository.findById(flatItemId).get(), flatItem));
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        String message = "";
        List<ObjectError> objectErrors = ex.getBindingResult().getAllErrors();
        for (int i = 0; i < objectErrors.size(); i++){
            ObjectError error = objectErrors.get(i);
            errors.put(((FieldError) error).getField(), error.getDefaultMessage());
        }
        return errors;
    }

}
