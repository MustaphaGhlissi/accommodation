package com.manten.api.flatExamination;

import com.fasterxml.jackson.annotation.JsonView;
import com.manten.api.flat.Flat;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="L_WohnungsMassnahme")
public class FlatExamination {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "WMID")
    private Long id;

    @Column(name = "CompID")
    @NotNull
    private Long compId;

    @Column(name = "WMKatalogID")
    @NotNull
    private Long flatExaminationTemplateId;

    @Column(name = "WMVorherigeMassnahmeID")
    private Long previousFlatExaminationId;

    @Column(name = "WMVerantwortlichMitarbeiterID")
    @NotNull
    private Long responsibleEmployeeId;

    @Column(name = "WMVerantwortlichExtern")
    private String responsibleExternal;

    @Column(name = "WMWohnungID")
    private Long flatId;

    @Column(name = "WMZimmerID")
    private Long roomId;

    @Column(name = "WMTerminGeplant")
    @NotNull
    private String datePlanned;

    @Column(name = "WMTerminDurchfuehrung")
    private String dateExecuted;

    @Column(name = "WMDringlichkeit")
    @NotNull
    private Integer priority;

    @Column(name = "WMStatusID")
    @NotNull
    private Integer state;

    @Column(name = "WMWohnungsStatus")
    private Integer flatState;

    @Column(name = "WMBemerkung")
    private String remark;

    public FlatExamination() {
    }

    /*public FlatExamination(Long id, @NotNull Long compId, @NotNull Long flatExaminationTemplateId, Long previousFlatExaminationId, @NotNull Long responsibleEmployeeId, String responsibleExternal, Long flatId, Long roomId, @NotNull String datePlanned, String dateExecuted, @NotNull Integer priority, @NotNull Integer state, Integer flatState, String remark) {
        this.id = id;
        this.compId = compId;
        this.flatExaminationTemplateId = flatExaminationTemplateId;
        this.previousFlatExaminationId = previousFlatExaminationId;
        this.responsibleEmployeeId = responsibleEmployeeId;
        this.responsibleExternal = responsibleExternal;
        this.flatId = flatId;
        this.roomId = roomId;
        this.datePlanned = datePlanned;
        this.dateExecuted = dateExecuted;
        this.priority = priority;
        this.state = state;
        this.flatState = flatState;
        this.remark = remark;
    }*/

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompId() {
        return compId;
    }

    public void setCompId(Long compId) {
        this.compId = compId;
    }

    public Long getFlatExaminationTemplateId() {
        return flatExaminationTemplateId;
    }

    public void setFlatExaminationTemplateId(Long flatExaminationTemplateId) {
        this.flatExaminationTemplateId = flatExaminationTemplateId;
    }

    public Long getPreviousFlatExaminationId() {
        return previousFlatExaminationId;
    }

    public void setPreviousFlatExaminationId(Long previousFlatExaminationId) {
        this.previousFlatExaminationId = previousFlatExaminationId;
    }

    public Long getResponsibleEmployeeId() {
        return responsibleEmployeeId;
    }

    public void setResponsibleEmployeeId(Long responsibleEmployeeId) {
        this.responsibleEmployeeId = responsibleEmployeeId;
    }

    public String getResponsibleExternal() {
        return responsibleExternal;
    }

    public void setResponsibleExternal(String responsibleExternal) {
        this.responsibleExternal = responsibleExternal;
    }

    public Long getFlatId() {
        return flatId;
    }

    public void setFlatId(Long flatId) {
        this.flatId = flatId;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public String getDatePlanned() {
        return datePlanned;
    }

    public void setDatePlanned(String datePlanned) {
        this.datePlanned = datePlanned;
    }

    public String getDateExecuted() {
        return dateExecuted;
    }

    public void setDateExecuted(String dateExecuted) {
        this.dateExecuted = dateExecuted;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Integer getFlatState() {
        return flatState;
    }

    public void setFlatState(Integer flatState) {
        this.flatState = flatState;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
