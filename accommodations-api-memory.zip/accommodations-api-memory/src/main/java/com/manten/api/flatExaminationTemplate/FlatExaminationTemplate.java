package com.manten.api.flatExaminationTemplate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "L_KatalogWohnung")
public class FlatExaminationTemplate {

    @Id
    @Column(name = "KWID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "KWBezeichnung")
    @NotNull
    private String description;

    @Column(name = "KWTyp")
    @NotNull
    private Integer type;

    @Column(name = "KWIntervall")
    @NotNull
    private Integer interval;

    @Column(name = "KWIntervallBezug")
    @NotNull
    private String intervalReference;

    @Column(name = "KWStausRelevant")
    @NotNull
    private Boolean stateRelevant;

    @Column(name = "KWBemerkung")
    private String remark;

    public FlatExaminationTemplate() {
    }

    public FlatExaminationTemplate(Long id, String description, Integer type, Integer interval, String intervalReference, Boolean stateRelevant, String remark) {
        this.id = id;
        this.description = description;
        this.type = type;
        this.interval = interval;
        this.intervalReference = intervalReference;
        this.stateRelevant = stateRelevant;
        this.remark = remark;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getInterval() {
        return interval;
    }

    public void setInterval(Integer interval) {
        this.interval = interval;
    }

    public String getIntervalReference() {
        return intervalReference;
    }

    public void setIntervalReference(String intervalReference) {
        this.intervalReference = intervalReference;
    }

    public Boolean getStateRelevant() {
        return stateRelevant;
    }

    public void setStateRelevant(Boolean stateRelevant) {
        this.stateRelevant = stateRelevant;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
