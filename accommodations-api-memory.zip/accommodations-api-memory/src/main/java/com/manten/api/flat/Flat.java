package com.manten.api.flat;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="L_Wohnungen")
public class Flat {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "Woid")
    private Long id;

    @Column(name = "WoAdrId")
    @NotNull
    private Long addressId;

    @Column(name = "CompID")
    @NotNull
    private Long compId;

    @Column(name = "MandantId")
    @NotNull
    private Long clientId;

    @Column(name = "WoAmpelStatus")
    @NotNull
    private Integer trafficLightState;

    @Column(name = "WoWohnung")
    private String name;

    public Flat() {
    }

    public Flat(Long id, @NotNull Long addressId, @NotNull Long compId, @NotNull Long clientId, @NotNull Integer trafficLightState, String name) {
        this.id = id;
        this.addressId = addressId;
        this.compId = compId;
        this.clientId = clientId;
        this.trafficLightState = trafficLightState;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAddressId() {
        return addressId;
    }

    public void setAddressId(Long addressId) {
        this.addressId = addressId;
    }

    public Long getCompId() {
        return compId;
    }

    public void setCompId(Long compId) {
        this.compId = compId;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Integer getTrafficLightState() {
        return trafficLightState;
    }

    public void setTrafficLightState(Integer trafficLightState) {
        this.trafficLightState = trafficLightState;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
