package com.manten.api.flatExamination;

import com.manten.api.flat.FlatRepository;
import com.manten.api.utils.Utils;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Validated
public class FlatExaminationController {

    private FlatExaminationRepository flatExaminationRepository;

    public FlatExaminationController(FlatExaminationRepository flatExaminationRepository, FlatRepository flatRepository){
        this.flatExaminationRepository = flatExaminationRepository;
    }

    @GetMapping("/flat-examinations")
    List<FlatExamination> all(){
        return flatExaminationRepository.findPendingFlatExaminations();
    }

    @PostMapping("/flat-examinations")
    FlatExamination create(@RequestBody @Valid FlatExamination flatExamination){
        return flatExaminationRepository.save(flatExamination);
    }

    @PatchMapping("/flat-examinations/{flatExaminationId}")
    FlatExamination update(@RequestBody FlatExamination flatExamination, @PathVariable Long flatExaminationId){
        return flatExaminationRepository.save((FlatExamination) Utils.mergeObjects(flatExaminationRepository.findById(flatExaminationId).get(), flatExamination));
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        String message = "";
        List<ObjectError> objectErrors = ex.getBindingResult().getAllErrors();
        for (int i = 0; i < objectErrors.size(); i++){
            ObjectError error = objectErrors.get(i);
            errors.put(((FieldError) error).getField(), error.getDefaultMessage());
        }
        return errors;
    }

}
