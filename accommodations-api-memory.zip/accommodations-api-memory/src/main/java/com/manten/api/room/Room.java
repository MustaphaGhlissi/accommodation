package com.manten.api.room;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="L_Zimmer")
public class Room {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "ZIID")
    private Long id;

    @Column(name = "CompID")
    @NotNull
    private Long compId;

    @Column(name = "MandantID")
    @NotNull
    private Long clientId;

    @Column(name = "ZIWohnungID")
    @NotNull
    private Long flatId;

    @Column(name = "ZIZimmerNummer")
    @NotNull
    private String number;

    @Column(name = "ZIEtage")
    private Long level;

    @Column(name = "ZISeite")
    private Long side;

    @Column(name = "ZIBemerkung")
    private String remark;

    public Room() {
    }

    public Room(Long id, @NotNull Long compId, @NotNull Long clientId, @NotNull Long flatId, @NotNull String number, Long level, Long side, String remark) {
        this.id = id;
        this.compId = compId;
        this.clientId = clientId;
        this.flatId = flatId;
        this.number = number;
        this.level = level;
        this.side = side;
        this.remark = remark;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompId() {
        return compId;
    }

    public void setCompId(Long compId) {
        this.compId = compId;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getFlatId() {
        return flatId;
    }

    public void setFlatId(Long flatId) {
        this.flatId = flatId;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public Long getLevel() {
        return level;
    }

    public void setLevel(Long level) {
        this.level = level;
    }

    public Long getSide() {
        return side;
    }

    public void setSide(Long side) {
        this.side = side;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
