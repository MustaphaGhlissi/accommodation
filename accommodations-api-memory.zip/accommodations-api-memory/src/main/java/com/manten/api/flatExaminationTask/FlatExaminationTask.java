package com.manten.api.flatExaminationTask;

import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.List;

@Entity
@Table(name = "L_WohnungsAufgabe")
public class FlatExaminationTask {

    @Id
    @Column(name = "WAID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "CompID")
    @NotNull
    private Long compId;

    @Column(name = "WaKatalogAufgabeID")
    private Long flatExaminationTaskTemplateId;

    @Column(name = "WAMassnahmeID")
    @NotNull
    private Long flatExaminationId;

    @Column(name = "WaBeschreibung")
    @NotNull
    private String description;

    @Column(name = "WaInventarID")
    private Long itemId;

    @Column(name = "WaErgebnis")
    @NotNull
    private Boolean result;

    @Column(name = "WaBemerkung")
    private String remark;

    public FlatExaminationTask() {
    }

    public FlatExaminationTask(Long id, @NotNull Long compId, Long flatExaminationTaskTemplateId, @NotNull Long flatExaminationId, @NotNull String description, Long itemId, @NotNull Boolean result, String remark) {
        this.id = id;
        this.compId = compId;
        this.flatExaminationTaskTemplateId = flatExaminationTaskTemplateId;
        this.flatExaminationId = flatExaminationId;
        this.description = description;
        this.itemId = itemId;
        this.result = result;
        this.remark = remark;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompId() {
        return compId;
    }

    public void setCompId(Long compId) {
        this.compId = compId;
    }

    public Long getFlatExaminationTaskTemplateId() {
        return flatExaminationTaskTemplateId;
    }

    public void setFlatExaminationTaskTemplateId(Long flatExaminationTaskTemplateId) {
        this.flatExaminationTaskTemplateId = flatExaminationTaskTemplateId;
    }

    public Long getFlatExaminationId() {
        return flatExaminationId;
    }

    public void setFlatExaminationId(Long flatExaminationId) {
        this.flatExaminationId = flatExaminationId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public Boolean getResult() {
        return result;
    }

    public void setResult(Boolean result) {
        this.result = result;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
