package com.manten.api.flatItem;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="L_WohnungArtikel")
public class FlatItem {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "WAID")
    private Long id;

    @Column(name = "CompID")
    @NotNull
    private Long compId;

    @Column(name = "WAWohnungID")
    @NotNull
    private Long flatId;

    @Column(name = "WAZimmerID")
    private Long roomId;

    @Column(name = "WAArtikelID")
    @NotNull
    private Long articleId;

    @Column(name = "WAAnzahl")
    @NotNull
    private Integer quantity;

    @Column(name = "WABemerkung")
    private String remark;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompId() {
        return compId;
    }

    public void setCompId(Long compId) {
        this.compId = compId;
    }

    public Long getFlatId() {
        return flatId;
    }

    public void setFlatId(Long flatId) {
        this.flatId = flatId;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public Long getArticleId() {
        return articleId;
    }

    public void setArticleId(Long articleId) {
        this.articleId = articleId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
