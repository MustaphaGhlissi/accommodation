package com.manten.api.flatExaminationTaskPhoto;

import com.manten.api.utils.Utils;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class FlatExaminationTaskPhotoController {

    private FlatExaminationTaskPhotoRepository flatExaminationTaskPhotoRepository;

    public FlatExaminationTaskPhotoController(FlatExaminationTaskPhotoRepository flatExaminationTaskPhotoRepository){
        this.flatExaminationTaskPhotoRepository = flatExaminationTaskPhotoRepository;
    }

    @PostMapping("/flat-examination-task-photos")
    FlatExaminationTaskPhoto create(@RequestBody @Validated FlatExaminationTaskPhoto flatExaminationTaskPhoto){
        byte[] decode = Base64.decodeBase64(flatExaminationTaskPhoto.getPhoto());
        String binaryStr = new BigInteger(1, decode).toString(2);
        flatExaminationTaskPhoto.setPhoto(binaryStr);
        return flatExaminationTaskPhotoRepository.save(flatExaminationTaskPhoto);
    }

    @PatchMapping("/flat-examination-task-photos/{flatExaminationTaskPhotoId}")
    FlatExaminationTaskPhoto update(@RequestBody FlatExaminationTaskPhoto flatExaminationTaskPhoto, @PathVariable Long flatExaminationTaskPhotoId){
        return flatExaminationTaskPhotoRepository.save((FlatExaminationTaskPhoto)Utils.mergeObjects(flatExaminationTaskPhotoRepository.findById(flatExaminationTaskPhotoId).get(), flatExaminationTaskPhoto));
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        String message = "";
        List<ObjectError> objectErrors = ex.getBindingResult().getAllErrors();
        for (int i = 0; i < objectErrors.size(); i++){
            ObjectError error = objectErrors.get(i);
            errors.put(((FieldError) error).getField(), error.getDefaultMessage());
        }
        return errors;
    }

}
