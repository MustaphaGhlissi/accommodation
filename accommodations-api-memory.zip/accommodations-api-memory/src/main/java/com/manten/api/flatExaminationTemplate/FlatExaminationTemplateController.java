package com.manten.api.flatExaminationTemplate;

import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Validated
public class FlatExaminationTemplateController {

    private FlatExaminationTemplateRepository flatExaminationTemplateRepository;

    public FlatExaminationTemplateController(FlatExaminationTemplateRepository flatExaminationTemplateRepository) {
        this.flatExaminationTemplateRepository = flatExaminationTemplateRepository;
    }

    @GetMapping("/flat-examination-templates")
    List<FlatExaminationTemplate> all(){
        return flatExaminationTemplateRepository.findAll();
    }

    @PostMapping("/flat-examination-templates")
    FlatExaminationTemplate create(@RequestBody @Valid FlatExaminationTemplate flatExaminationTemplate){
        return flatExaminationTemplateRepository.save(flatExaminationTemplate);
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        String message = "";
        List<ObjectError> objectErrors = ex.getBindingResult().getAllErrors();
        for (int i = 0; i < objectErrors.size(); i++){
            ObjectError error = objectErrors.get(i);
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            message = message + fieldName + ": " + errorMessage + (i < objectErrors.size() - 1 ? ", " : "");
        }
        errors.put("message", message);
        return errors;
    }
}
