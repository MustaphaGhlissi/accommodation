package com.manten.api.flatExaminationTask;

import com.manten.api.utils.Utils;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class FlatExaminationTaskController {

    private FlatExaminationTaskRepository flatExaminationTaskRepository;

    public FlatExaminationTaskController(FlatExaminationTaskRepository flatExaminationTaskRepository){
        this.flatExaminationTaskRepository = flatExaminationTaskRepository;
    }

    @GetMapping("/flat-examination-tasks")
    List<FlatExaminationTask> all(){
        //return flatExaminationTaskRepository.findTop200ByOrderByDatePlannedDesc();
        return flatExaminationTaskRepository.findFlatExaminationsOfPendingFlatExaminations();
    }

    @PostMapping("/flat-examination-tasks")
    FlatExaminationTask create(@RequestBody @Validated FlatExaminationTask flatExaminationTask){
        return flatExaminationTaskRepository.save(flatExaminationTask);
    }

    @PatchMapping("/flat-examination-tasks/{flatExaminationTaskId}")
    FlatExaminationTask update(@RequestBody FlatExaminationTask flatExaminationTask, @PathVariable Long flatExaminationTaskId){
        return flatExaminationTaskRepository.save((FlatExaminationTask)Utils.mergeObjects(flatExaminationTaskRepository.findById(flatExaminationTaskId).get(), flatExaminationTask));
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        String message = "";
        List<ObjectError> objectErrors = ex.getBindingResult().getAllErrors();
        for (int i = 0; i < objectErrors.size(); i++){
            ObjectError error = objectErrors.get(i);
            errors.put(((FieldError) error).getField(), error.getDefaultMessage());
        }
        return errors;
    }

}
