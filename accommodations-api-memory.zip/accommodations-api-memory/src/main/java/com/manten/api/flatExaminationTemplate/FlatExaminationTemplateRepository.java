package com.manten.api.flatExaminationTemplate;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FlatExaminationTemplateRepository extends JpaRepository<FlatExaminationTemplate, Long> {
}
