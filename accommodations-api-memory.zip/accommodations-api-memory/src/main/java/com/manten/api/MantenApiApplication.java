package com.manten.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MantenApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MantenApiApplication.class, args);
	}

}
