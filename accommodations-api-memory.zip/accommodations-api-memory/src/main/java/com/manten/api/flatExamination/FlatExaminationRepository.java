package com.manten.api.flatExamination;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Collection;
import java.util.List;

public interface FlatExaminationRepository extends JpaRepository<FlatExamination, Long> {

    /*@Query("select fe, fl from FlatExamination fe inner join fe.flat fl")
    List<FlatExamination> getAllWithFlat();*/

    //public List<FlatExamination> findTop50ByOrderByDatePlannedDesc();

    @Query("select fe from FlatExamination fe where fe.state = 264")
    public List<FlatExamination> findPendingFlatExaminations();

}
