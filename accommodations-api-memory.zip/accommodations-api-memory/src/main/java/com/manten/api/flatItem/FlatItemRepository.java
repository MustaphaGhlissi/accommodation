package com.manten.api.flatItem;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FlatItemRepository extends JpaRepository<FlatItem, Long> {
}
