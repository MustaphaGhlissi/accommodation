package com.manten.api.flatExaminationTaskPhoto;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "G_MobileDokumente")
public class FlatExaminationTaskPhoto {

    @Id
    @Column(name="MDID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="MDMandant")
    private Long clientId = -1L;

    @Column(name="MDBezugTabelle")
    private String referencedTable = "L_WohnungsAufgaben";

    @Column(name="MDBezugID")
    @NotNull
    private String referenceId;

    @Column(name="MDDateiName")
    private String fileName = "test";

    @Column(name="MDDatei")
    @NotNull
    @Lob
    private String photo;

    @Column(name="MDUserID")
    private Long userId = -1L;

    public FlatExaminationTaskPhoto() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getClientId() {
        return clientId;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public String getReferencedTable() {
        return referencedTable;
    }

    public void setReferencedTable(String referencedTable) {
        this.referencedTable = referencedTable;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
