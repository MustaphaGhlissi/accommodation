package com.manten.api.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class Utils {

    public static Object mergeObjects(Object obj1, Object obj2) {
        try {
            Field[] allFields = obj1.getClass().getDeclaredFields();
            for (Field field : allFields) {

                if (!field.isAccessible() && Modifier.isPrivate(field.getModifiers()))
                    field.setAccessible(true);
                if (field.get(obj2) != null) {
                    field.set(obj1, field.get(obj2));
                }
            }
            return obj1;
        } catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

}
