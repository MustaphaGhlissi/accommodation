package com.manten.api.flatExaminationTaskTemplate;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class FlatExaminationTaskTemplateController {

    private FlatExaminationTaskTemplateRepository flatExaminationTaskTemplateRepository;

    public FlatExaminationTaskTemplateController(FlatExaminationTaskTemplateRepository flatExaminationTaskTemplateRepository) {
        this.flatExaminationTaskTemplateRepository = flatExaminationTaskTemplateRepository;
    }

    @GetMapping("/flat-examination-task-templates")
    List<FlatExaminationTaskTemplate> all(){
        return flatExaminationTaskTemplateRepository.findAll();
    }

    @PostMapping("/flat-examination-task-templates")
    FlatExaminationTaskTemplate create(@RequestBody FlatExaminationTaskTemplate flatExaminationTaskTemplate){
        return flatExaminationTaskTemplateRepository.save(flatExaminationTaskTemplate);
    }
}
