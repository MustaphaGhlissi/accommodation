package com.manten.api.flatExaminationTask;

import com.manten.api.flatExamination.FlatExamination;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface FlatExaminationTaskRepository extends JpaRepository<FlatExaminationTask, Long> {

    //public List<FlatExaminationTask> findTop200ByOrderByDatePlannedDesc();

    @Query("select fet from FlatExaminationTask fet where fet.flatExaminationId in (select fe.id from FlatExamination fe where fe.state = 264)")
    public List<FlatExaminationTask> findFlatExaminationsOfPendingFlatExaminations();

}
