package com.manten.api.flatExaminationTaskPhoto;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FlatExaminationTaskPhotoRepository extends JpaRepository<FlatExaminationTaskPhoto, Long> {

}
